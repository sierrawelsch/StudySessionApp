package cs3500.pa02;

/**
 * Represents a questions difficulty
 */
public enum Level {
  EASY, HARD
}
