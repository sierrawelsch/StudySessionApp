# Vectors
- [[Vectors act like resizable arrays]].

## Declaring a vector
- [[General Form: Vector<type> v = new Vector();]]
- Example: Vector<Integer> v = new Vector();
- [[What is the capital of Canada?:::The capital is Ottawa.]]
- [[type needs to be a valid reference type]]

## Adding an element to a vector
- [[v.add(object of type);]]
- [[Which country is known as the Land of the Rising Sun?:::Japan.]]
- [[What is the largest river in Africa? ::: The largest river is the Nile River.]]
- Reminder - go back and review clearing a vector!
- [[Which country is famous for its tulips and windmills?:::

The Netherlands.]]