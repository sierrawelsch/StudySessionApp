[[What is the tallest mountain in North America?:::The tallest mountain is Denali (also known as Mount McKinley).]]
[[Which continent is known as the "Roof of the World"?:::Asia.]]
[[What is the largest desert in Asia? ::: The largest desert is the Gobi Desert.]]
[[Which country is the smallest in terms of land area?::: The smallest country is Vatican City.]]
[[What is the official language of Brazil? :::The official language is Portuguese.]]
[[What is the official language of Japan?:::The official language is Japanese.]]
[[Which country is the driest inhabited continent on Earth?:::Australia.]]
[[What is the largest coral reef system in the world? ::: The largest coral reef system is the Great Barrier Reef in Australia.]]
[[What is the capital of Argentina?:::

The capital is Buenos Aires.]]